export async function triggerWorkflow(input: {
  action?: string;
  payload?: any;
}) {
  const res = await fetch("/api/autopilot", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      naturalLanguage: input.action,
      payload: input.payload,
    }),
  });

  if (!res.ok) {
    throw new Error("Autopilot failed");
  }

  return res.json();
}
