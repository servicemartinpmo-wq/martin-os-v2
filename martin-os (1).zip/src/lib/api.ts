import { supabase } from './supabase';

export async function fetchWithLogging(url: string, options?: RequestInit) {
  const res = await fetch(url, options);
  const text = await res.text();
  try {
    const data = JSON.parse(text);
    if (!res.ok) {
        console.error(`Request failed for ${url}, status: ${res.status}, response:`, text);
        throw new Error(data.error || `Request failed with status ${res.status}`);
    }
    return data;
  } catch (err) {
    console.error(`JSON parse error for ${url}, got response:`, text);
    throw err;
  }
}

export async function fetchUserRole(userId: string) {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('role')
      .eq('id', userId)
      .single();

    if (error) throw error;
    return data.role;
  } catch (err) {
    console.error('Error fetching user role:', err);
    return null; // fallback
  }
}

export async function safeFetch(table: string, options: any = {}) {
  try {
    const { data, error } = await supabase
      .from(table)
      .select(options.select || '*')
      .eq(options.eqColumn || '', options.eqValue || '')
      .order(options.orderColumn || 'created_at', { ascending: false })
      .limit(options.limit || 10);

    if (error) throw error;
    return data || [];
  } catch (err) {
    console.error(`Error fetching ${table}:`, err);
    return [];
  }
}
