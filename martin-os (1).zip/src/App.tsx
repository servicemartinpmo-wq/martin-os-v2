/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, lazy, Suspense } from 'react';
import { supabase } from './lib/supabase';
import { Session } from '@supabase/supabase-js';
import Auth from './components/auth/Auth';
import LandingPage from './components/landing/LandingPage';
import AboutPage from './components/landing/pages/AboutPage';
import ContactPage from './components/landing/pages/ContactPage';
import BlogPage from './components/landing/pages/BlogPage';
import DiscoveryCallPage from './components/landing/pages/DiscoveryCallPage';
const Sidebar = lazy(() => import('./components/layout/Sidebar'));
const OnboardingFlow = lazy(() => import('./components/onboarding/OnboardingFlow'));
const ExecutiveDashboard = lazy(() => import('./components/dashboard/ExecutiveDashboard'));
const InitiativesPage = lazy(() => import('./components/initiatives/InitiativesPage'));
const TeamPage = lazy(() => import('./components/team/TeamPage'));
const AdvisoryDesk = lazy(() => import('./components/advisory/AdvisoryDesk'));
const ReportsPage = lazy(() => import('./components/reports/ReportsPage'));
const SystemsPage = lazy(() => import('./components/systems/SystemsPage'));
const TechDashboard = lazy(() => import('./components/tech-ops/TechDashboard'));
const TicketsPage = lazy(() => import('./components/tech-ops/TicketsPage'));
const MiidleFeed = lazy(() => import('./components/miidle/MiidleFeed'));
const WorkGraph = lazy(() => import('./components/miidle/WorkGraph'));
const CreativePortfolio = lazy(() => import('./components/creative/CreativePortfolio'));
const AssistedDashboard = lazy(() => import('./components/assisted/AssistedDashboard'));
const ProjectHub = lazy(() => import('./components/project/ProjectHub'));
const FreelanceHub = lazy(() => import('./components/freelance/FreelanceHub'));
const HealthcareDashboard = lazy(() => import('./components/healthcare/HealthcareDashboard'));
const OfficeDashboard = lazy(() => import('./components/admin/OfficeDashboard'));
const FounderDashboard = lazy(() => import('./components/founder/FounderDashboard'));
const DiagnosticsPage = lazy(() => import('./components/tech-ops/DiagnosticsPage'));
import { Toaster } from 'sonner';
const OSInterface = lazy(() => import('./components/OSInterface'));
const DynamicOSPage = lazy(() => import('./components/DynamicOSPage'));
import ErrorBoundary from './components/shared/ErrorBoundary';

// New Dashboards
const ExecutiveCommandCenter = lazy(() => import('./components/dashboard/ExecutiveCommandCenter'));
const InitiativeDashboard = lazy(() => import('./components/dashboard/InitiativeDashboard'));
const OrganizationalMap = lazy(() => import('./components/dashboard/OrganizationalMap'));
const ResourceHub = lazy(() => import('./components/dashboard/ResourceHub'));
const KnowledgeSuperbase = lazy(() => import('./components/dashboard/KnowledgeSuperbase'));
const CoreSystemShell = lazy(() => import('./components/dashboard/CoreSystemShell'));

const IntelligenceAdvisoryLayer = lazy(() => import('./components/shared/IntelligenceAdvisoryLayer'));
const BehavioralEngine = lazy(() => import('./components/BehavioralEngine'));
const AdminDashboard = lazy(() => import('./components/AdminDashboard').then(m => ({ default: m.AdminDashboard })));
import { AIProvider } from './context/AIContext';
const CompanyIntelligence = lazy(() => import('./components/shared/CompanyIntelligence'));
const ConsultingInABox = lazy(() => import('./components/shared/ConsultingInABox'));
const OneClickDiagnostics = lazy(() => import('./components/shared/OneClickDiagnostics'));
const ProjectWorkManagement = lazy(() => import('./components/shared/ProjectWorkManagement'));
const DecisionMemorySystem = lazy(() => import('./components/shared/DecisionMemorySystem'));
const KPIAnalyticsEngine = lazy(() => import('./components/shared/KPIAnalyticsEngine'));
const WorkflowAutomation = lazy(() => import('./components/shared/WorkflowAutomation'));
const DataOperatingSystem = lazy(() => import('./components/shared/DataOperatingSystem'));
const MarketingIntelligence = lazy(() => import('./components/shared/MarketingIntelligence'));
const AdminControlPanel = lazy(() => import('./components/shared/AdminControlPanel'));
const AssistedOnboarding = lazy(() => import('./components/shared/AssistedOnboarding'));
const PersonalizationEngine = lazy(() => import('./components/shared/PersonalizationEngine'));
const UserEngagementSystem = lazy(() => import('./components/shared/UserEngagementSystem'));
const UniversalConnectivity = lazy(() => import('./components/shared/UniversalConnectivity'));
const ActionItems = lazy(() => import('./components/shared/ActionItems'));
const Preferences = lazy(() => import('./components/shared/Preferences'));
const CRM = lazy(() => import('./components/shared/CRM'));
const Marketing = lazy(() => import('./components/shared/Marketing'));
const LockscreenBanner = lazy(() => import('./components/dashboard/LockscreenBanner'));
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, Settings as SettingsIcon, Info } from 'lucide-react';
import { AppMode, AppType, CoreSystemId } from './types';
import { cn } from './lib/utils';

const AIAssistant = lazy(() => import('./components/shared/AIAssistant'));

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [isOnboarded, setIsOnboarded] = useState(false);
  const [currentApp, setCurrentApp] = useState<AppType>('PMO-OPs');
  const [currentMode, setCurrentMode] = useState<AppMode>('Executive');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [dynamicPath, setDynamicPath] = useState<string | null>(null);
  const [showHealthcareDisclaimer, setShowHealthcareDisclaimer] = useState(true);
  const [landingPage, setLandingPage] = useState<string | null>(null);

  useEffect(() => {
    if (!supabase) {
      // Don't auto-set session anymore, wait for "Try Demo" or similar if we want to show LandingPage
      return;
    }

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Reset active tab and dynamic path when switching apps
  // Reset active tab when mode or app changes
  useEffect(() => {
    setDynamicPath(null);
    if (currentApp === 'PMO-OPs') {
      setActiveTab('dashboard');
    } else if (currentApp === 'TECH-OPs') {
      setActiveTab('tech-dashboard');
    } else if (currentApp === 'miidle') {
      setActiveTab('feed');
    } else {
      setActiveTab('dashboard');
    }
  }, [currentMode, currentApp]);

  const renderContent = () => {
    if (!isOnboarded) {
      return <OnboardingFlow onComplete={(data) => {
        setIsOnboarded(true);
        setCurrentMode(data.mode as AppMode);
      }} />;
    }
    console.log("Rendering Content", { activeTab, currentApp, currentMode, dynamicPath });

    // Handle Dynamic OS Paths
    if (currentApp === 'UnifiedOS' && dynamicPath) {
      return <DynamicOSPage path={dynamicPath} onBack={() => setDynamicPath(null)} />;
    }

    // Shared components mapping for all apps and modes
    const sharedComponents: Record<string, React.ReactNode> = {
      // Main Dashboards
      'executive-command-center': <Suspense fallback={<div className="p-8">Loading...</div>}><ExecutiveCommandCenter mode={currentMode} /></Suspense>,
      'initiative-dashboard': <Suspense fallback={<div className="p-8">Loading...</div>}><InitiativeDashboard mode={currentMode} /></Suspense>,
      'organizational-map': <Suspense fallback={<div className="p-8">Loading...</div>}><OrganizationalMap mode={currentMode} /></Suspense>,
      'resource-hub': <Suspense fallback={<div className="p-8">Loading...</div>}><ResourceHub mode={currentMode} /></Suspense>,
      'knowledge-superbase': <Suspense fallback={<div className="p-8">Loading...</div>}><KnowledgeSuperbase mode={currentMode} /></Suspense>,

      // Core Systems (25)
      'strategic-alignment': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="strategic-alignment" mode={currentMode} /></Suspense>,
      'initiative-health': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="initiative-health" mode={currentMode} /></Suspense>,
      'execution-discipline': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="execution-discipline" mode={currentMode} /></Suspense>,
      'dependency-intelligence': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="dependency-intelligence" mode={currentMode} /></Suspense>,
      'org-capacity': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="org-capacity" mode={currentMode} /></Suspense>,
      'bottleneck-detection': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="bottleneck-detection" mode={currentMode} /></Suspense>,
      'risk-escalation': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="risk-escalation" mode={currentMode} /></Suspense>,
      'portfolio-optimization': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="portfolio-optimization" mode={currentMode} /></Suspense>,
      'org-health-scoring': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="org-health-scoring" mode={currentMode} /></Suspense>,
      'process-improvement': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="process-improvement" mode={currentMode} /></Suspense>,
      'strategic-risk-forecasting': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="strategic-risk-forecasting" mode={currentMode} /></Suspense>,
      'resource-allocation': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="resource-allocation" mode={currentMode} /></Suspense>,
      'leadership-bandwidth': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="leadership-bandwidth" mode={currentMode} /></Suspense>,
      'cross-dept-coordination': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="cross-dept-coordination" mode={currentMode} /></Suspense>,
      'execution-velocity': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="execution-velocity" mode={currentMode} /></Suspense>,
      'opportunity-detection': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="opportunity-detection" mode={currentMode} /></Suspense>,
      'decision-support': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="decision-support" mode={currentMode} /></Suspense>,
      'initiative-recovery': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="initiative-recovery" mode={currentMode} /></Suspense>,
      'strategic-planning': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="strategic-planning" mode={currentMode} /></Suspense>,
      'innovation-pipeline': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="innovation-pipeline" mode={currentMode} /></Suspense>,
      'change-management': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="change-management" mode={currentMode} /></Suspense>,
      'performance-benchmarking': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="performance-benchmarking" mode={currentMode} /></Suspense>,
      'knowledge-intelligence': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="knowledge-intelligence" mode={currentMode} /></Suspense>,
      'predictive-analytics': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="predictive-analytics" mode={currentMode} /></Suspense>,
      'executive-insight': <Suspense fallback={<div className="p-8">Loading...</div>}><CoreSystemShell systemId="executive-insight" mode={currentMode} /></Suspense>,
      'admin': <Suspense fallback={<div className="p-8">Loading...</div>}><AdminDashboard /></Suspense>,

      // Legacy/Shared
      'intelligence-advisory': <Suspense fallback={<div className="p-8">Loading...</div>}><IntelligenceAdvisoryLayer mode={currentMode} workspaceId="default-workspace" /></Suspense>,
      'company-intel': <Suspense fallback={<div className="p-8">Loading...</div>}><CompanyIntelligence mode={currentMode} /></Suspense>,
      'consulting': <Suspense fallback={<div className="p-8">Loading...</div>}><ConsultingInABox mode={currentMode} /></Suspense>,
      'diagnostics': <Suspense fallback={<div className="p-8">Loading...</div>}><OneClickDiagnostics mode={currentMode} /></Suspense>,
      'project-mgmt': <Suspense fallback={<div className="p-8">Loading...</div>}><ProjectWorkManagement mode={currentMode} /></Suspense>,
      'decision-mem': <Suspense fallback={<div className="p-8">Loading...</div>}><DecisionMemorySystem mode={currentMode} /></Suspense>,
      'kpi-analytics': <Suspense fallback={<div className="p-8">Loading...</div>}><KPIAnalyticsEngine mode={currentMode} /></Suspense>,
      'automation': <Suspense fallback={<div className="p-8">Loading...</div>}><WorkflowAutomation mode={currentMode} /></Suspense>,
      'data-os': <Suspense fallback={<div className="p-8">Loading...</div>}><DataOperatingSystem mode={currentMode} /></Suspense>,
      'marketing': <Suspense fallback={<div className="p-8">Loading...</div>}><MarketingIntelligence mode={currentMode} /></Suspense>,
      'admin-control': <Suspense fallback={<div className="p-8">Loading...</div>}><AdminControlPanel mode={currentMode} /></Suspense>,
      'onboarding': <Suspense fallback={<div className="p-8">Loading...</div>}><AssistedOnboarding mode={currentMode} /></Suspense>,
      'personalization': <Suspense fallback={<div className="p-8">Loading...</div>}><PersonalizationEngine mode={currentMode} /></Suspense>,
      'engagement': <Suspense fallback={<div className="p-8">Loading...</div>}><UserEngagementSystem mode={currentMode} /></Suspense>,
      'connectivity': <Suspense fallback={<div className="p-8">Loading...</div>}><UniversalConnectivity mode={currentMode} /></Suspense>,
      'preferences': <Suspense fallback={<div className="p-8">Loading...</div>}><Preferences /></Suspense>,
      'crm': <Suspense fallback={<div className="p-8">Loading...</div>}><CRM /></Suspense>,
      'marketing-hub': <Suspense fallback={<div className="p-8">Loading...</div>}><Marketing /></Suspense>,
      'actions': <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>,
    };

    // If the active tab is a shared component, render it
    if (sharedComponents[activeTab]) {
      return <div className="p-8">{sharedComponents[activeTab]}</div>;
    }

    // If TECH-OPs is selected
    if (currentApp === 'TECH-OPs') {
      switch (activeTab) {
        case 'tech-dashboard': return <Suspense fallback={<div className="p-8">Loading...</div>}><TechDashboard mode={currentMode} /></Suspense>;
        case 'diagnostics': return <Suspense fallback={<div className="p-8">Loading...</div>}><DiagnosticsPage mode={currentMode} /></Suspense>;
        case 'tickets': return <Suspense fallback={<div className="p-8">Loading...</div>}><TicketsPage mode={currentMode} /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
        default: return <Suspense fallback={<div className="p-8">Loading...</div>}><TechDashboard mode={currentMode} /></Suspense>;
      }
    }

    // If UnifiedOS is selected
    if (currentApp === 'UnifiedOS') {
      return <OSInterface onNavigate={setDynamicPath} />;
    }

    if (currentApp === 'miidle') {
      switch (activeTab) {
        case 'feed': return <Suspense fallback={<div className="p-8">Loading...</div>}><MiidleFeed mode={currentMode} /></Suspense>;
        case 'actions': return <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>;
        case 'graph': return <Suspense fallback={<div className="p-8">Loading...</div>}><WorkGraph /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
        default: return <Suspense fallback={<div className="p-8">Loading...</div>}><MiidleFeed mode={currentMode} /></Suspense>;
      }
    }

    // PMO-OPs (Default) - Uses the 8 modes
    if (currentMode === 'Founder/SMB') {
      switch (activeTab) {
        case 'dashboard': return <Suspense fallback={<div className="p-8">Loading...</div>}><FounderDashboard /></Suspense>;
        case 'actions': return <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>;
        case 'team': return <Suspense fallback={<div className="p-8">Loading...</div>}><TeamPage /></Suspense>;
        case 'reports': return <Suspense fallback={<div className="p-8">Loading...</div>}><ReportsPage /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
      }
    }

    // Executive Tabs
    if (currentMode === 'Executive') {
      switch (activeTab) {
        case 'dashboard': return <Suspense fallback={<div className="p-8">Loading...</div>}><ExecutiveDashboard /></Suspense>;
        case 'actions': return <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>;
        case 'reporting': return <Suspense fallback={<div className="p-8">Loading...</div>}><ReportsPage /></Suspense>;
        case 'team-mgmt': return <Suspense fallback={<div className="p-8">Loading...</div>}><TeamPage /></Suspense>;
        case 'strategy': return <Suspense fallback={<div className="p-8">Loading...</div>}><InitiativesPage /></Suspense>;
        case 'advisory': return <Suspense fallback={<div className="p-8">Loading...</div>}><AdvisoryDesk /></Suspense>;
        case 'behavior': return <Suspense fallback={<div className="p-8">Loading...</div>}><BehavioralEngine /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
      }
    }

    // Startup/Project Tabs
    if (currentMode === 'Startup/Project') {
      switch (activeTab) {
        case 'dashboard': return <Suspense fallback={<div className="p-8">Loading...</div>}><ProjectHub /></Suspense>;
        case 'actions': return <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>;
        case 'team': return <Suspense fallback={<div className="p-8">Loading...</div>}><TeamPage /></Suspense>;
        case 'reporting': return <Suspense fallback={<div className="p-8">Loading...</div>}><ReportsPage /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
      }
    }

    // Admin/Office Tabs
    if (currentMode === 'Admin/Office') {
      switch (activeTab) {
        case 'dashboard': return <Suspense fallback={<div className="p-8">Loading...</div>}><OfficeDashboard /></Suspense>;
        case 'actions': return <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>;
        case 'team': return <Suspense fallback={<div className="p-8">Loading...</div>}><TeamPage /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
      }
    }

    // Freelance Tabs
    if (currentMode === 'Freelance') {
      switch (activeTab) {
        case 'dashboard': return <Suspense fallback={<div className="p-8">Loading...</div>}><FreelanceHub /></Suspense>;
        case 'actions': return <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
      }
    }

    // Creative Tabs
    if (currentMode === 'Creative') {
      switch (activeTab) {
        case 'dashboard': return <Suspense fallback={<div className="p-8">Loading...</div>}><CreativePortfolio /></Suspense>;
        case 'actions': return <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>;
        case 'projections': return <Suspense fallback={<div className="p-8">Loading...</div>}><ReportsPage /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
      }
    }

    // Healthcare Tabs
    if (currentMode === 'Healthcare') {
      switch (activeTab) {
        case 'dashboard': return <Suspense fallback={<div className="p-8">Loading...</div>}><HealthcareDashboard /></Suspense>;
        case 'actions': return <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
      }
    }

    // Assisted Tabs
    if (currentMode === 'Assisted') {
      switch (activeTab) {
        case 'dashboard': return <Suspense fallback={<div className="p-8">Loading...</div>}><AssistedDashboard /></Suspense>;
        case 'actions': return <Suspense fallback={<div className="p-8">Loading...</div>}><ActionItems mode={currentMode} app={currentApp} /></Suspense>;
        case 'settings': return <Suspense fallback={<div className="p-8">Loading...</div>}><SystemsPage mode={currentMode} /></Suspense>;
      }
    }

    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400 p-8 text-center">
        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
          <span className="text-2xl font-bold">?</span>
        </div>
        <h3 className="text-lg font-bold text-slate-900">Module Under Construction</h3>
        <p className="max-w-xs mt-2">The {activeTab} module is currently being optimized by the Apphia engine.</p>
      </div>
    );
  };

  const handleWorkflowTrigger = async (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    const trigger = target.closest('[data-workflow]') as HTMLElement;
    if (!trigger) return;

    const workflowType = trigger.dataset.workflow;
    
    // High-performance trigger logic
    console.log(`Executing Workflow: ${workflowType}`);
    
    // Add an "Optimistic" visual feedback immediately
    trigger.classList.add('scale-95', 'opacity-50');
    setTimeout(() => trigger.classList.remove('scale-95', 'opacity-50'), 150);

    try {
      const response = await fetch('/api/workflow/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: workflowType, payload: {} })
      });
      const data = await response.json();
      console.log('Workflow result:', data);
    } catch (error) {
      console.error('Workflow execution failed:', error);
    }
  };

  return (
    <AIProvider>
      <Toaster position="top-right" richColors theme="dark" />
      <ErrorBoundary>
        {!session ? (
          <div className="relative min-h-screen">
            {landingPage === 'product' ? (
              <div className="min-h-screen bg-[#010409] text-white p-20">
                <button onClick={() => setLandingPage(null)} className="mb-4 text-slate-400 hover:text-white">← Back</button>
                <h1 className="text-4xl font-bold mb-6">Product</h1>
                <p className="text-slate-400">Our product is designed for leaders to act with confidence.</p>
              </div>
            ) : landingPage === 'pricing' ? (
              <div className="min-h-screen bg-[#010409] text-white p-20">
                <button onClick={() => setLandingPage(null)} className="mb-4 text-slate-400 hover:text-white">← Back</button>
                <h1 className="text-4xl font-bold mb-6">Pricing</h1>
                <p className="text-slate-400">Choose the plan that fits your leadership needs.</p>
              </div>
            ) : landingPage === 'about' ? (
              <AboutPage />
            ) : landingPage === 'contact' ? (
              <ContactPage />
            ) : landingPage === 'blog' ? (
              <BlogPage />
            ) : landingPage === 'discovery' ? (
              <DiscoveryCallPage />
            ) : landingPage === 'signin' ? (
              <div className="min-h-screen bg-[#010409] text-white p-20 flex items-center justify-center">
                <div className="w-full max-w-md">
                  <button onClick={() => setLandingPage(null)} className="mb-4 text-slate-400 hover:text-white">← Back</button>
                  <Auth 
                    onSignInSuccess={() => setLandingPage(null)} 
                    onSignUpSuccess={() => setLandingPage(null)} 
                  />
                </div>
              </div>
            ) : (
              <LandingPage 
                onInitialize={() => {
                  setIsOnboarded(false);
                  setLandingPage(null);
                }} 
                onExplore={() => window.scrollTo({ top: window.innerHeight, behavior: 'smooth' })} 
                onNavigate={(page) => setLandingPage(page)}
              />
            )}
          </div>
        ) : (
          <div onClick={handleWorkflowTrigger} className={cn(
            "flex h-screen bg-white font-sans text-black overflow-hidden",
            currentMode === 'Assisted' && "text-lg"
          )}>
            <Sidebar 
              activeTab={activeTab} 
              setActiveTab={setActiveTab} 
              currentMode={currentMode} 
              setMode={setCurrentMode} 
              currentApp={currentApp}
              setApp={setCurrentApp}
            />
            
            <main className="flex-1 overflow-y-auto bg-white relative">
              {currentMode === 'Healthcare' && showHealthcareDisclaimer && (
                <div className="sticky top-14 z-30 bg-amber-50 border-b border-amber-200 px-8 py-2 flex items-center justify-between shadow-sm animate-in slide-in-from-top duration-300">
                  <div className="flex items-center gap-3 text-amber-800">
                    <ShieldAlert className="w-4 h-4 text-amber-600" />
                    <p className="text-[10px] font-bold tracking-widest uppercase">
                      <span className="font-black">REGULATORY DISCLAIMER:</span> This interface is for administrative and operational oversight only. Clinical decisions must be made by licensed professionals. All data is HIPAA-compliant and encrypted.
                    </p>
                  </div>
                  <button 
                    onClick={() => setShowHealthcareDisclaimer(false)}
                    className="p-1 hover:bg-amber-100 rounded-full transition-colors"
                  >
                    <span className="text-[10px] font-bold text-amber-600 uppercase tracking-widest px-2">Dismiss</span>
                  </button>
                </div>
              )}
              {/* Top Bar / Global Alerts */}
              <div className="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-slate-100 px-8 py-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Workspace:</span>
                  <span className="px-2 py-0.5 bg-slate-900 text-white text-[10px] font-bold rounded uppercase tracking-tighter">Martin-OS</span>
                  <div className="h-3 w-[1px] bg-slate-200 mx-1" />
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status:</span>
                  <span className={cn(
                    "px-2 py-0.5 text-[10px] font-bold rounded border uppercase tracking-tighter",
                    "bg-green-50 text-green-600 border-green-100"
                  )}>
                    Optimized
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
                  </p>
                </div>
              </div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={`${currentMode}-${activeTab}`}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.2 }}
                  className="h-full"
                >
                  {renderContent()}
                </motion.div>
              </AnimatePresence>
            </main>
            <AIAssistant />
          </div>
        )}
      </ErrorBoundary>
    </AIProvider>
  );
}

