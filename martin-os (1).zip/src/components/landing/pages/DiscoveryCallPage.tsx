import React from 'react';

export default function DiscoveryCallPage() {
  return (
    <div className="min-h-screen bg-[#010409] text-white p-20">
      <h1 className="text-5xl font-bold mb-8">Book A Discovery Call</h1>
      <p className="text-xl text-slate-400 mb-8">Let's discuss how we can help your organization thrive.</p>
      <p className="text-lg text-slate-300">Schedule a time to speak with our team about your operational challenges and how our Tri-Pillar System Solution can support your sustainable growth.</p>
    </div>
  );
}
