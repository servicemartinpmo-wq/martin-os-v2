import React from 'react';

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-[#010409] text-white p-20">
      <h1 className="text-5xl font-bold mb-8">Blog</h1>
      <p className="text-xl text-slate-400 mb-8">Insights and updates from Martin PMO.</p>
      <p className="text-lg text-slate-300">Stay tuned for our latest articles on operational excellence, project management, and sustainable growth strategies.</p>
    </div>
  );
}
