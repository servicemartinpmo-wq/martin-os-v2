import React from 'react';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-[#010409] text-white p-20">
      <h1 className="text-5xl font-bold mb-8">About Martin PMO</h1>
      <p className="text-xl text-slate-400 mb-8">Martin PMO delivers more than just staffing support, we build the systems that power sustainable growth.</p>
      <p className="text-lg text-slate-300">We specialize in operational solutions that empower organizations to scale efficiently. Our approach is rooted in deep expertise and a commitment to helping leaders act with confidence.</p>
    </div>
  );
}
