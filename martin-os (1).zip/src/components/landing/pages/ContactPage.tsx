import React from 'react';

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-[#010409] text-white p-20">
      <h1 className="text-5xl font-bold mb-8">Contact Us</h1>
      <p className="text-xl text-slate-400 mb-8">Get in touch with the Martin PMO team to discuss your operational needs.</p>
      <p className="text-lg text-slate-300">We are here to help you build the systems that power sustainable growth. Reach out to us for inquiries, partnerships, or to learn more about our services.</p>
    </div>
  );
}
