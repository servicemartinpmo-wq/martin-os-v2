import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';
import { MotionValue, useMotionValueEvent } from 'motion/react';

function ParticleGrid({ rotation }: { rotation: MotionValue<number> }) {
  const points = useRef<THREE.Points>(null!);
  const currentRotation = useRef(rotation.get());

  useMotionValueEvent(rotation, "change", (latest) => {
    currentRotation.current = latest;
  });
  
  // Generate random points
  const count = 5000;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count * 3; i++) {
    positions[i] = (Math.random() - 0.5) * 10;
  }

  useFrame((state) => {
    points.current.rotation.x = currentRotation.current + state.clock.getElapsedTime() * 0.05;
    points.current.rotation.y = currentRotation.current * 0.5 + state.clock.getElapsedTime() * 0.02;
  });

  return (
    <Points ref={points} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#3b82f6"
        size={0.02}
        sizeAttenuation={true}
        depthWrite={false}
      />
    </Points>
  );
}

export default function ThreeBackground({ rotation }: { rotation: MotionValue<number> }) {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas camera={{ position: [0, 0, 5] }}>
        <ParticleGrid rotation={rotation} />
      </Canvas>
    </div>
  );
}
