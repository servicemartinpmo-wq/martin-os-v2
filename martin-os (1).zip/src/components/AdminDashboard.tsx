import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { GeminiChat } from './shared/GeminiChat';
import { ImageAnalyzer } from './shared/ImageAnalyzer';
import { generateContent } from '../services/geminiService';
import { AIResultModal } from './shared/AIResultModal';

export const AdminDashboard = () => {
  const [isAdmin, setIsAdmin] = useState(false);
  const [searchResult, setSearchResult] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    const checkAdmin = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user?.email === 'service.martinpmo@gmail.com') {
        setIsAdmin(true);
      }
    };
    checkAdmin();
  }, []);

  const runSearch = async () => {
    setLoading(true);
    setIsModalOpen(true);
    try {
      const result = await generateContent('What is the current status of MARTIN OS development?', {
        model: 'gemini-3-flash-preview',
        tools: [{ googleSearch: {} }]
      });
      setSearchResult(result || 'No status report generated.');
    } catch (error) {
      console.error('Admin search error:', error);
      setSearchResult('Error generating system health check.');
    } finally {
      setLoading(false);
    }
  };

  if (!isAdmin) return <div>Access Denied</div>;

  return (
    <div className="p-8 space-y-8">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-bold mb-4">System Health & Search</h2>
          <button 
            onClick={runSearch}
            className="bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-slate-800 transition-colors"
          >
            Run System Health Check (with Search)
          </button>
        </div>

        <ImageAnalyzer />
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-bold mb-4">Gemini Brain Chat</h2>
        <GeminiChat systemInstruction="You are the system administrator assistant for MARTIN OS. Be concise and helpful." />
      </div>

      <AIResultModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="System Health Check"
        content={searchResult}
        loading={loading}
      />
    </div>
  );
};
