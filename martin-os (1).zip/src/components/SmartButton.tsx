"use client";

import { triggerWorkflow } from "../lib/workflowClient";

type SmartButtonProps = {
  label?: string;
  action: string; // e.g. "create_task", "assign_user"
  payload?: any;
  className?: string;
};

export default function SmartButton({
  label,
  action,
  payload,
  className,
  children,
}: SmartButtonProps & { children?: React.ReactNode }) {
  const handleClick = async () => {
    try {
      await triggerWorkflow({
        action,
        payload,
      });
    } catch (err) {
      console.error("Workflow trigger failed:", err);
    }
  };

  return (
    <button onClick={handleClick} className={className}>
      {children || label}
    </button>
  );
}
