'use client';
import { useChat } from '@ai-sdk/react';
import { useState, useEffect } from 'react';
import { 
  Activity, 
  Shield, 
  Zap, 
  Target,
  BarChart3, 
  Loader2, 
  ChevronRight, 
  LayoutGrid, 
  Database, 
  Cpu,
  RefreshCw,
  CheckCircle2,
  Users, 
  Mail, 
  FileText, 
  Settings, 
  HelpCircle, 
  MessageSquare,
  ChevronLeft,
  Mic
} from 'lucide-react';
import { cn } from '../lib/utils';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';

import { useOSRealtime } from '../hooks/useOSRealtime';
import SignalAlert from './SignalAlert';
import SmartSignalPopup from './SmartSignalPopup';
import OSHeader from './OSHeader';
import CommsDraftCard from './CommsDraftCard';
import InsightCard from './InsightCard';
import DepartmentCard from './DepartmentCard';
import FrameworkPanel from './FrameworkPanel';
import ExecutiveLoadMeter from './ExecutiveLoadMeter';
import ExecutiveDashboard from './ExecutiveDashboard';
import InitiativesPage from './InitiativesPage';
import ActionItemsPage from './ActionItemsPage';
import TeamPage from './TeamPage';
import ResourceHub from './ResourceHub';
import SystemsPage from './SystemsPage';
import ReportsPage from './ReportsPage';
import AdvisoryNetwork from './AdvisoryNetwork';
import AdminPage from './AdminPage';
import WorkflowBuilder from './WorkflowBuilder';
import QualityControlView from './QualityControlView';
import IntegrationsPage from './IntegrationsPage';

// --- Sub-components ---

const SystemLog = ({ logs }: { logs: { time: string, msg: string, type: 'info' | 'error' | 'success' }[] }) => (
  <div className="bg-black/40 backdrop-blur-md border border-white/10 rounded-2xl p-4 font-mono text-[10px] h-48 overflow-y-auto custom-scrollbar shadow-inner">
    <div className="text-blue-500 mb-3 uppercase tracking-widest border-b border-white/5 pb-2 flex justify-between items-center">
      <span>System_Kernel_Output</span>
      <span className="opacity-30 text-[8px]">v2.1.0-LAMINATED</span>
    </div>
    <div className="space-y-1">
      {logs.map((log, i) => (
        <div key={i} className="flex gap-2 animate-in fade-in slide-in-from-left-1 duration-300">
          <span className="text-white/20 shrink-0">[{log.time}]</span>
          <span className={cn(
            "break-all",
            log.type === 'error' ? 'text-rose-400' : 
            log.type === 'success' ? 'text-emerald-400' : 
            'text-blue-300'
          )}>
            {log.msg}
          </span>
        </div>
      ))}
      {logs.length === 0 && <div className="text-white/10 italic">Awaiting kernel initialization...</div>}
    </div>
  </div>
);

// --- Main Interface ---

interface OSInterfaceProps {
  onNavigate?: (path: string) => void;
}

export default function OSInterface({ onNavigate }: OSInterfaceProps) {
  const { alerts, lastSync } = useOSRealtime();
  const [activeModule, setActiveModule] = useState('DASHBOARD');
  const [systemLogs, setSystemLogs] = useState<{ time: string, msg: string, type: 'info' | 'error' | 'success' }[]>([
    { time: new Date().toLocaleTimeString(), msg: 'Kernel initialized. Thinking Engine v2.1.0 online.', type: 'info' },
    { time: new Date().toLocaleTimeString(), msg: 'Supabase connection established.', type: 'success' },
    { time: new Date().toLocaleTimeString(), msg: 'Executive Load Meter calibrated.', type: 'info' },
  ]);
  const [systemStatus, setSystemStatus] = useState<'optimal' | 'drift'>('optimal');
  const [departments, setDepartments] = useState<any[]>([
    { id: '1', name: 'Operations', maturity_score: 88, health_status: 'optimal', lead_role_key: 'EXEC_DIR' },
    { id: '2', name: 'Program Delivery', maturity_score: 72, health_status: 'drift', lead_role_key: 'PROG_COORD' },
  ]);
  const [activeSignal, setActiveSignal] = useState<{ key: string, message: string } | null>(null);
  
  const { messages, input, handleInputChange, handleSubmit, isLoading, append } = useChat({
    api: '/api/os/engine',
    body: { modelPreference: 'gemini' },
    onResponse: (response) => {
      console.log('[OS Engine] Response received:', response.status);
    },
    onError: (error) => {
      console.error('[OS Engine] Error:', error);
    },
    onFinish: (message) => {
      console.log('[OS Engine] Finished:', message.content.substring(0, 50) + '...');
    }
  });

  // Anomaly Detection Simulation
  useEffect(() => {
    if (!supabase) return;
    const checkPulse = async () => {
      try {
        const { data: tasks } = await supabase.from('tasks').select('id').eq('status', 'todo');
        if (tasks && tasks.length > 5) {
          setSystemStatus('drift');
          addLog('Tech-Ops: Operational drift detected in PMO-Ops. Task backlog exceeding threshold.', 'error');
          
          // Trigger a PMO Signal if not already active
          if (!activeSignal) {
            setActiveSignal({
              key: 'LEADERSHIP_BANDWIDTH',
              message: 'Decision delay detected in Program Delivery. 12 approvals pending for > 48h.'
            });
          }
        } else {
          setSystemStatus('optimal');
        }
      } catch (e) {
        console.warn('Pulse check failed:', e);
      }
    };
    const interval = setInterval(checkPulse, 15000);
    return () => clearInterval(interval);
  }, [activeSignal]);

  const addLog = (msg: string, type: 'info' | 'error' | 'success' = 'info') => {
    setSystemLogs(prev => [{ time: new Date().toLocaleTimeString(), msg, type }, ...prev].slice(0, 50));
  };

  // FIX: Event Delegation - This captures ALL button clicks in the OS
  const handleOSControl = (e: React.MouseEvent) => {
    const trigger = (e.target as HTMLElement).closest('[data-action]');
    if (!trigger) return;

    const action = (trigger as HTMLElement).dataset.action;
    const value = (trigger as HTMLElement).dataset.value;

    // 1. Visual feedback (Futuristic Laminated Effect)
    trigger.classList.add('brightness-150', 'scale-95', 'shadow-[0_0_20px_rgba(59,130,246,0.6)]');
    trigger.setAttribute('data-state', 'processing');
    setTimeout(() => {
      trigger.classList.remove('brightness-150', 'scale-95');
      trigger.removeAttribute('data-state');
    }, 200);

    // 2. Logging
    addLog(`Operator: Triggered ${action} [${value}]`);

    // 3. Logic Routing
    if (action === 'nav') {
      setActiveModule(value || 'DASHBOARD');
      toast.info(`Switching to ${value}-OPS`, {
        description: `Initializing ${value} operational context...`,
        duration: 2000
      });
    }
    if (action === 'workflow') {
      // Check for dynamic navigation commands
      if (value?.startsWith('os/')) {
        onNavigate?.(value.replace('os/', ''));
        return;
      }

      // Optimistic UI Feedback
      toast.promise(
        fetch('/api/apphia/route', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ action, value }),
        }).then(async (res) => {
          if (!res.ok) throw new Error('Failed to route workflow');
          return res.json();
        }),
        {
          loading: `Executing ${value?.replace('_', ' ')}...`,
          success: (res) => {
            addLog(`System: Workflow ${value} completed.`, 'success');
            return `Workflow ${value} initiated successfully.`;
          },
          error: (err) => {
            addLog(`System: Workflow ${value} failed.`, 'error');
            return `Failed to initiate ${value}. Check system logs.`;
          },
        }
      );
    }
  };

  const renderModule = () => {
    const commonProps = { user: { firstName: 'Martin', meetingsToday: [] }, org: { name: 'MARTIN OS', executiveLoad: 72 } };
    
    switch (activeModule) {
      case 'DASHBOARD':
        return <ExecutiveDashboard {...commonProps} />;
      case 'INITIATIVES':
        return <InitiativesPage initiatives={[]} />;
      case 'INTEGRATIONS':
        return <IntegrationsPage />;
      case 'ACTION_ITEMS':
        return <ActionItemsPage actionItems={[]} />;
      case 'TEAM':
        return <TeamPage team={[]} />;
      case 'ADVISORY':
        return <AdvisoryNetwork />;
      case 'WORKFLOW':
        return <WorkflowBuilder />;
      case 'ADMIN':
        return <AdminPage />;
      case 'RESOURCES':
        return <ResourceHub />;
      case 'SYSTEMS':
        return <SystemsPage />;
      case 'REPORTS':
        return <ReportsPage />;
      default:
        return (
          <div className="grid grid-cols-2 gap-6">
            {departments.map(dept => (
              <DepartmentCard key={dept.id} department={dept} />
            ))}
          </div>
        );
    }
  };

  return (
    <div 
      onClick={handleOSControl}
      className="min-h-screen bg-[#020202] text-slate-100 font-sans p-6 selection:bg-blue-500/40 overflow-x-hidden"
    >
      {/* Floating Alert Stack (Top Right) */}
      <div className="fixed top-24 right-6 w-80 z-50 space-y-4">
        {alerts.map((alert) => (
          <SignalAlert key={alert.id} alert={alert} />
        ))}
      </div>

      {/* Smart Signal Popup (Top Left) */}
      {activeSignal && (
        <SmartSignalPopup 
          systemKey={activeSignal.key}
          message={activeSignal.message}
          onDismiss={() => setActiveSignal(null)}
          onAction={() => {
            addLog(`Operator: Running diagnostics for ${activeSignal.key}`);
            setActiveSignal(null);
            toast.success("Diagnostic sequence initiated.");
          }}
        />
      )}

      {/* Background Glows */}
      <div className="fixed top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-900/10 rounded-full blur-[150px] pointer-events-none" />
      <div className="fixed bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-cyan-900/10 rounded-full blur-[150px] pointer-events-none" />
  
      {/* OS Header with Last Sync Metadata */}
      <header className="max-w-7xl mx-auto mb-4">
        <OSHeader isThinking={isLoading} currentModel="LOGIC-MODULE-V2.1" />
        <div className="px-4 py-2 text-[9px] text-slate-500 font-mono tracking-widest uppercase flex justify-between items-center">
          <div>Signal Pulse: <span className="text-emerald-500">{lastSync}</span> | Status: <span className="text-blue-400">{isLoading ? 'Processing' : 'Listening'}</span></div>
          <div className="opacity-30">v2.1.0-AUTONOMOUS</div>
        </div>
      </header>

      {/* Logic Module Overlay */}
      {isLoading && (
        <div className="fixed inset-0 z-[100] bg-[#020202]/60 backdrop-blur-sm flex items-center justify-center pointer-events-none">
          <div className="cinematic-panel p-8 flex flex-col items-center gap-6 border-blue-500/30 shadow-[0_0_50px_rgba(59,130,246,0.2)]">
            <div className="relative">
              <div className="w-24 h-24 rounded-full border-2 border-blue-500/20 animate-ping" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Cpu className="w-10 h-10 text-blue-400 animate-pulse" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <h4 className="text-xl font-black text-white tracking-tighter uppercase">Logic Module Active</h4>
              <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.3em] animate-pulse">Synchronizing System Chains...</p>
            </div>
            <div className="w-64 h-1 bg-white/5 rounded-full overflow-hidden">
              <div className="h-full bg-blue-500 animate-loading" />
            </div>
          </div>
        </div>
      )}

      {/* Simplified Navigation Container */}
      <nav className="max-w-7xl mx-auto nav-container overflow-x-auto no-scrollbar">
        {[
          { id: 'dashboard', label: 'Dashboard', icon: LayoutGrid },
          { id: 'initiatives', label: 'Initiatives', icon: Target },
          { id: 'action_items', label: 'Actions', icon: CheckCircle2 },
          { id: 'workflow', label: 'Workflows', icon: Zap },
          { id: 'team', label: 'Team', icon: Users },
          { id: 'resources', label: 'Resources', icon: FileText },
          { id: 'reports', label: 'Reports', icon: BarChart3 },
          { id: 'integrations', label: 'Integrations', icon: Database },
          { id: 'systems', label: 'Systems', icon: Shield },
          { id: 'advisory', label: 'Advisory', icon: MessageSquare },
          { id: 'admin', label: 'Admin', icon: Settings },
        ].map((item) => (
          <button
            key={item.id}
            data-action="nav"
            data-value={item.id.toUpperCase()}
            className={cn(
              "flex items-center gap-2 px-6 py-2 rounded-xl transition-all group",
              activeModule === item.id.toUpperCase() ? "bg-blue-500/20 text-blue-400 border border-blue-500/30" : "text-slate-500 hover:text-slate-300"
            )}
          >
            <item.icon className="w-4 h-4" />
            <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="max-w-7xl mx-auto grid grid-cols-12 gap-8 relative z-10">
        {/* Column 1: Intelligence & Frameworks */}
        <aside className="col-span-3 space-y-6">
          <FrameworkPanel 
            activeFrameworks={[
              { id: 'okr', name: 'OKRs', status: 'active', icon: Target, color: 'blue' },
              { id: 'lean', name: 'Lean', status: 'optimizing', icon: Zap, color: 'cyan' },
              { id: 'toc', name: 'TOC', status: 'evaluating', icon: Shield, color: 'purple' },
              { id: 'rumelt', name: 'Rumelt', status: 'active', icon: Activity, color: 'blue' },
            ]} 
          />
          
          <div className="space-y-4">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 px-4">Strategic Insights</h3>
            {/* Insights will be rendered here via Chat or static list */}
            <div className="opacity-40 grayscale scale-95">
               <InsightCard insight={{
                 situation: "Budget drift in Dept A",
                 diagnosis: "Coordination problem",
                 recommendation: "Shift resources",
                 structural_remedy: "Update framework",
                 framework: "RUMELT",
                 timestamp: "10:42"
               }} />
            </div>
          </div>
        </aside>
        {/* Column 2: Operations & Execution */}
        <main className="col-span-6 space-y-8">
          {renderModule()}

          {/* Module Quick-Nav - Removed as per Audit 3 Navigation Simplification */}

          {/* Chat Interface */}
          <div className="space-y-4">
            <div className="h-[450px] bg-white/[0.02] backdrop-blur-md border border-white/5 rounded-3xl p-6 overflow-y-auto space-y-4 custom-scrollbar shadow-inner">
              {messages.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center opacity-20 space-y-4">
                  <Zap className="w-12 h-12 text-blue-500" />
                  <p className="text-sm font-bold uppercase tracking-widest">Awaiting System Initialization...</p>
                </div>
              )}
              {messages.map(m => (
                <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={cn(
                    "max-w-[90%] p-5 rounded-2xl text-sm border transition-all",
                    m.role === 'user' 
                      ? 'bg-blue-600/10 border-blue-500/20 text-blue-50 shadow-[0_0_30px_rgba(37,99,235,0.05)]' 
                      : 'bg-white/5 border-white/10 text-slate-200'
                  )}>
                    <div className="flex items-center gap-2 mb-2 opacity-40">
                      <span className="text-[10px] font-black uppercase tracking-widest">
                        {m.role === 'user' ? 'Operator' : 'System'}
                      </span>
                    </div>
                    <p className="leading-relaxed whitespace-pre-wrap">{m.content}</p>
                    
                    {/* Tool Invocations Rendering */}
                    {m.toolInvocations?.map((toolInvocation) => {
                      const { toolName, toolCallId, state } = toolInvocation;

                      if (state === 'result') {
                        const { result } = toolInvocation;
                        
                        if (toolName === 'communicationDraft') {
                          return (
                            <div key={toolCallId} className="mt-4">
                              <CommsDraftCard draft={result} />
                            </div>
                          );
                        }
                        
                        if (toolName === 'generateStrategicInsight') {
                          return (
                            <div key={toolCallId} className="mt-4">
                              <InsightCard insight={result} />
                            </div>
                          );
                        }

                        if (toolName === 'calculateExecutiveScores') {
                          return (
                            <div key={toolCallId} className="mt-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl">
                              <div className="flex items-center gap-2 mb-2">
                                <Target className="w-4 h-4 text-blue-400" />
                                <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Intelligence Update</span>
                              </div>
                              <p className="text-xs text-white font-bold">{result.intelligence}</p>
                              <div className="mt-2 text-[24px] font-black text-blue-400">{result.score}<span className="text-xs text-slate-500 ml-1">/ 100</span></div>
                            </div>
                          );
                        }
                      }
                      return null;
                    })}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex items-center gap-3 p-4 bg-blue-500/5 border border-blue-500/10 rounded-2xl w-fit">
                  <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />
                  <span className="text-[10px] font-black text-blue-400 animate-pulse tracking-widest uppercase">Thinking...</span>
                </div>
              )}
            </div>

            {/* Input Area */}
            <form onSubmit={handleSubmit} className="relative group">
              <div className="absolute inset-0 bg-blue-500/5 blur-xl group-focus-within:bg-blue-500/10 transition-all rounded-2xl" />
              <input 
                value={input}
                onChange={handleInputChange}
                placeholder="Inject command into thinking engine or use voice..."
                className="w-full bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 pr-32 outline-none focus:border-blue-500/50 transition-all text-lg shadow-2xl relative z-10 placeholder:text-slate-600"
              />
              <div className="absolute right-4 top-4 flex items-center gap-2 z-20">
                <button 
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    toast.info("Voice recognition activated. Listening...");
                  }}
                  className="p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all group"
                >
                  <Mic className="w-6 h-6 text-slate-400 group-hover:text-blue-400 transition-colors" />
                </button>
                <button 
                  type="submit" 
                  disabled={isLoading || !input.trim()}
                  className="p-3 bg-blue-600 rounded-xl hover:bg-blue-500 shadow-lg transition-all disabled:opacity-50 disabled:grayscale"
                >
                  <ChevronRight className="w-6 h-6 text-white" />
                </button>
              </div>
            </form>
          </div>
        </main>

        {/* Column 3: Control & Diagnostics */}
        <aside className="col-span-3 space-y-6">
          <div className="bg-white/5 backdrop-blur-xl p-8 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl -mr-16 -mt-16" />
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-400 mb-6">System Control</h3>
            <div className="grid gap-4">
              {[
                { label: 'Full DB Re-Sync', value: 'sync_db', icon: RefreshCw },
                { label: 'Tech Troubleshooter', value: 'tech_troubleshoot', icon: HelpCircle },
                { label: 'Run PMO Audit', value: 'run_audit', icon: Activity },
                { label: 'System Diagnostic', value: 'run_diagnostic', icon: Shield },
                { label: 'Optimize Memory', value: 'optimize_memory', icon: Zap },
                { label: 'Marketing Ops (AI)', value: 'os/marketing-ops', icon: BarChart3 },
              ].map((btn) => (
                <button 
                  key={btn.value}
                  data-action="workflow" 
                  data-value={btn.value} 
                  className="group flex items-center justify-between p-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 transition-all text-left"
                >
                  <div className="flex items-center gap-3">
                    <btn.icon className="w-4 h-4 text-slate-400 group-hover:text-blue-400 transition-colors" />
                    <span className="text-xs font-bold text-slate-300 group-hover:text-white transition-colors">{btn.label}</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-blue-400 transition-all group-hover:translate-x-1" />
                </button>
              ))}
            </div>
          </div>

          {/* System Kernel Log */}
          <SystemLog logs={systemLogs} />

          {/* Live System Feed */}
          <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/5">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4">Live Feed</h3>
            <div className="space-y-4">
              {[
                { time: '16:55', msg: 'PMO-Ops: Ticket #482 synchronized.', type: 'success' },
                { time: '16:54', msg: 'Tech-Ops: Diagnostic pipeline at 98%.', type: 'info' },
                { time: '16:50', msg: 'miidle: New build story generated.', type: 'info' },
              ].map((log, i) => (
                <div key={i} className="flex gap-3 text-[10px] font-mono">
                  <span className="text-slate-600">{log.time}</span>
                  <span className={cn(
                    "font-bold",
                    log.type === 'success' ? 'text-emerald-500' : 'text-blue-400'
                  )}>{log.msg}</span>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
