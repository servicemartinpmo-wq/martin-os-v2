import React, { useState, useEffect } from 'react';
import { Activity, Shield, Zap, Target, BarChart3, Loader2 } from 'lucide-react';
import { cn } from '../lib/utils';
import { escalationEngine, Signal } from '../services/escalationEngine';

export default function DiagnosticCommandCenter() {
  const [signals, setSignals] = useState<Signal[]>([]);
  const [loading, setLoading] = useState(false);

  // In a real app, use Supabase real-time subscription here
  useEffect(() => {
    // Mock data for demonstration
    setSignals([
      { id: '1', description: 'API Latency High', tier_level: 2 },
      { id: '2', description: 'VPN Access Issue', tier_level: 1 },
    ]);
  }, []);

  const handleAction = async (signal: Signal) => {
    setLoading(true);
    try {
      const result = await escalationEngine.routeSignal(signal);
      console.log('Action executed:', result);
      // Update UI/Supabase status
    } catch (error) {
      console.error('Action failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-md border border-white/10 rounded-3xl p-8 shadow-2xl">
      <h2 className="text-xl font-black text-white uppercase tracking-widest mb-6">Diagnostic Command Center</h2>
      <div className="space-y-4">
        {signals.map((signal) => (
          <div key={signal.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
            <div>
              <p className="text-sm font-bold text-white">{signal.description}</p>
              <p className="text-[10px] text-blue-400 uppercase tracking-widest">Tier {signal.tier_level}</p>
            </div>
            <button 
              onClick={() => handleAction(signal)}
              disabled={loading}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-xl text-xs font-bold text-white transition-all"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Execute'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
